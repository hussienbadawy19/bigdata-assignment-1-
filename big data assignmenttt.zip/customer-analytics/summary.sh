#!/bin/bash
echo "========================================="
echo "COPYING RESULTS TO HOST"
echo "========================================="
mkdir -p /app/pipeline/results/
cp *.csv /app/pipeline/results/ 2>/dev/null && echo "CSV files copied" || echo "No CSV files"
cp *.txt /app/pipeline/results/ 2>/dev/null && echo "TXT files copied" || echo "No TXT files"
cp *.png /app/pipeline/results/ 2>/dev/null && echo "PNG files copied" || echo "No PNG files"
echo ""
echo "Results copied to /app/pipeline/results/"
echo ""
echo "Files in results:"
ls -la /app/pipeline/results/
echo ""
echo "Exiting container..."
exit