import subprocess
import sys
import os
import time

def run_pipeline(dataset_path):
    print("\n" + "="*60)
    print("STARTING DATA PIPELINE")
    print("="*60)
    
    start_time = time.time()
    
    print("\n[1/5] Running ingest.py...")
    result = subprocess.run([sys.executable, 'ingest.py', dataset_path], 
                          capture_output=True, text=True)
    print(result.stdout)
    if result.returncode != 0:
        print(f"Error: {result.stderr}")
        return False
    
    print("\n[2/5] Running preprocess.py...")
    result = subprocess.run([sys.executable, 'preprocess.py', 'data_raw.csv'], 
                          capture_output=True, text=True)
    print(result.stdout)
    if result.returncode != 0:
        print(f"Error: {result.stderr}")
        return False
    
    print("\n[3/5] Running analytics.py...")
    result = subprocess.run([sys.executable, 'analytics.py', 'data_preprocessed.csv'], 
                          capture_output=True, text=True)
    print(result.stdout)
    if result.returncode != 0:
        print(f"Error: {result.stderr}")
        return False
    
    print("\n[4/5] Running visualize.py...")
    result = subprocess.run([sys.executable, 'visualize.py', 'data_preprocessed.csv'], 
                          capture_output=True, text=True)
    print(result.stdout)
    if result.returncode != 0:
        print(f"Error: {result.stderr}")
        return False
    
    print("\n[5/5] Running cluster.py...")
    result = subprocess.run([sys.executable, 'cluster.py', 'data_preprocessed.csv'], 
                          capture_output=True, text=True)
    print(result.stdout)
    if result.returncode != 0:
        print(f"Error: {result.stderr}")
        return False
    
    elapsed_time = time.time() - start_time
    
    print("\n" + "="*60)
    print("PIPELINE COMPLETED SUCCESSFULLY")
    print(f"Time: {elapsed_time:.2f} seconds")
    print("="*60)
    
    return True

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python run_pipeline.py <dataset_path>")
        sys.exit(1)
    
    dataset_path = sys.argv[1]
    if not os.path.exists(dataset_path):
        print(f"Error: File {dataset_path} does not exist")
        sys.exit(1)
    
    success = run_pipeline(dataset_path)
    sys.exit(0 if success else 1)