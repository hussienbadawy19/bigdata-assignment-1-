import sys
import pandas as pd
import numpy as np
import re
from sklearn.preprocessing import StandardScaler, LabelEncoder
import os

def main():
    if len(sys.argv) != 2:
        print("Usage: python preprocess.py <input_csv_file>")
        sys.exit(1)
    
    input_file = sys.argv[1]
    
    if not os.path.exists(input_file):
        print(f"Error: File {input_file} does not exist")
        sys.exit(1)
   
    df = pd.read_csv(input_file)  
    
    df.head()
    df.shape
    df.size
    df.dtypes
    df.isna().sum()
# ============================================
# 1. Remove Duplicates
# ============================================
df.duplicated().sum()
df.drop_duplicates(inplace=True)
df.duplicated().sum()
df.isna().sum()
#============================================
# 2. Drop Unwanted columns
# ============================================
df = df.drop(['Video graphics Memorey','Display Refresh Rate','Processor Generation','Product number','SUPPORT SSD M2'], axis=1)
df.isna().sum()
df.info()
# ============================================
# 3. Fill Missing Values
# ============================================
df['Brand:'] = df['Brand:'].fillna(df['Brand:'].mode()[0])
df['Video graphics'] = df['Video graphics'].fillna(df['Video graphics'].mode()[0])
df['Display'] = df['Display'].fillna(df['Display'].mode()[0])
df['Colors'] = df['Colors'].fillna(df['Colors'].mode()[0])
df['Display Resolution'] = df['Display Resolution'].fillna(df['Display Resolution'].mode()[0])
df['Operating System'] = df['Operating System'].fillna(df['Operating System'].mode()[0])
df['Keyboard'] = df['Keyboard'].fillna(df['Keyboard'].mode()[0])
df['Battery'] = df['Battery'].fillna(df['Battery'].mode()[0])
df['Webcam'] = df['Webcam'].fillna(df['Webcam'].mode()[0])
df['Connections'] = df['Connections'].fillna(df['Connections'].mode()[0])
df['Dimensions'] = df['Dimensions'].fillna(df['Dimensions'].mode()[0])
df['Weight'] = df['Weight'].fillna(df['Weight'].mode()[0])
df['Processor Details'] = df['Processor Details'].fillna(df['Processor Details'].mode()[0])

df.isna().sum()
# ============================================
# 4. Feature Transformation
# ============================================
categorical_cols = ['Brand:', 'Video graphics', 'Display', 'Colors', 
                    'Display Resolution', 'Operating System', 'Keyboard', 
                    'Battery', 'Webcam', 'Connections', 'Processor Details']

# Apply Label Encoding
label_encoders = {}
for col in categorical_cols:
    le = LabelEncoder()
    df[col + '_encoded'] = le.fit_transform(df[col].astype(str))
    label_encoders[col] = le

# Keep numerical columns
numerical_cols = ['RAM', 'Hard drive', 'Weight', 'Price']  # Adjust based on your actual columns
if 'Weight' in df.columns:
    # Extract numeric from Weight if it contains units
    df['Weight_numeric'] = df['Weight'].str.extract('(\d+\.?\d*)').astype(float)

# Select features for PCA
features = [col + '_encoded' for col in categorical_cols] + numerical_cols
# Add any other numerical columns you have
if 'Weight_numeric' in df.columns:
    features.append('Weight_numeric')

from sklearn.preprocessing import LabelEncoder

le = LabelEncoder()

df['Operating System'] = le.fit_transform(df['Operating System'])
df = pd.get_dummies(df, columns=['Operating System'], drop_first=True)
# ============================================
# 5. Scalling
# ============================================
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()

df[['Price']] = scaler.fit_transform(df[['Price']])

from sklearn.decomposition import PCA
if len(numeric_cols) > 2:
    pca = PCA(n_components=min(3, len(numeric_cols)))
    pca_result = pca.fit_transform(df[numeric_cols])
    pca_cols = [f'PCA_{i+1}' for i in range(pca.n_components_)]
    df_pca = pd.DataFrame(pca_result, columns=pca_cols)
    df = pd.concat([df, df_pca], axis=1)
    print(f"Applied PCA: reduced to {pca.n_components_} components")
# ============================================
# 6. Binning
# ============================================
df['Price_bin'] = pd.cut(df['Price'], bins=3, labels=['Low', 'Medium', 'High'])
df['Price_bin']